﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using Newtonsoft.Json;

namespace EkzamenLustVersion
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string SaveFileName = "recipes.json";

        private ObservableCollection<Recipe> recipes = new ObservableCollection<Recipe>();
        private Recipe currentRecipe;

        public MainWindow()
        {
            InitializeComponent();
            RecipesListBox.ItemsSource = recipes;
            LoadRecipesFromFile();
        }
        private void SaveRecipesToFile()
        {
            string json = JsonConvert.SerializeObject(recipes);
            File.WriteAllText(SaveFileName, json);
        }

        private void LoadRecipesFromFile()
        {
            if (File.Exists(SaveFileName))
            {
                string json = File.ReadAllText(SaveFileName);
                recipes = JsonConvert.DeserializeObject<ObservableCollection<Recipe>>(json);
                RecipesListBox.ItemsSource = recipes;
            }
        }
        private void Closer(object sender, System.ComponentModel.CancelEventArgs e)
        {
            SaveRecipesToFile();
        }

        private void NewRecipe_Click(object sender, RoutedEventArgs e)
        {
            currentRecipe = new Recipe();
            ShowRecipeDetails(currentRecipe);
        }

        private void RecipesListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (RecipesListBox.SelectedItem is Recipe selectedRecipe)
            {
                currentRecipe = selectedRecipe;
                ShowRecipeDetails(currentRecipe);
            }
        }

        private void ShowRecipeDetails(Recipe recipe)
        {
            RecipeDetailsPanel.Visibility = Visibility.Visible;

            TitleTextBox.Text = recipe.Title;
            DishTypeComboBox.SelectedItem = recipe.DishType;
            CuisineComboBox.SelectedItem = recipe.Cuisine;

            if (!string.IsNullOrEmpty(recipe.ImagePath))
            {
                RecipeImage.Source = new BitmapImage(new Uri(recipe.ImagePath));
            }
            else
            {
                RecipeImage.Source = null;
            }

            IngredientsDataGrid.ItemsSource = recipe.Ingredients;

            StepsItemsControl.ItemsSource = recipe.Steps;
        }

        private void LoadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.jpg, *.png)|*.jpg;*.png";

            if (openFileDialog.ShowDialog() == true)
            {
                RecipeImage.Source = new BitmapImage(new Uri(openFileDialog.FileName));
                currentRecipe.ImagePath = openFileDialog.FileName;
            }
        }

        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe != null)
            {
                currentRecipe.Steps.Add(new RecipeStep
                {
                    Number = currentRecipe.Steps.Count + 1,
                    Description = ""
                });
            }
        }

        private void SaveRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe == null) return;

            currentRecipe.Title = TitleTextBox.Text;
            currentRecipe.DishType = DishTypeComboBox.SelectedItem?.ToString();
            currentRecipe.Cuisine = CuisineComboBox.SelectedItem?.ToString();

            if (!recipes.Contains(currentRecipe))
            {
                recipes.Add(currentRecipe);
            }


            MessageBox.Show("Рецепт сохранен!", "Успех");
        }

        private void DeleteRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe != null && recipes.Contains(currentRecipe))
            {
                recipes.Remove(currentRecipe);
                RecipeDetailsPanel.Visibility = Visibility.Collapsed;
            }
        }

        

        
    }

    public class Recipe
    {
        public string Title { get; set; }
        public string DishType { get; set; }
        public string Cuisine { get; set; }
        public string ImagePath { get; set; }
        public ObservableCollection<Ingredient> Ingredients { get; set; } = new ObservableCollection<Ingredient>();
        public ObservableCollection<RecipeStep> Steps { get; set; } = new ObservableCollection<RecipeStep>();

    }

    public class Ingredient
    {
        public string Name { get; set; }
        public string Amount { get; set; }
    }

    public class RecipeStep
    {
        public int Number { get; set; }
        public string Description { get; set; }
    }
}
