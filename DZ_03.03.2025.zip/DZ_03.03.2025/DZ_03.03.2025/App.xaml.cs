﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace DZ_03._03._2025
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
