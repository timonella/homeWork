﻿using System.Windows;

namespace Culc
{
    public partial class MainWindow : Window
    {
        List<string> A = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
        }
        
        public void Btn_1(object sender, RoutedEventArgs e)
        {
            textBox1.Text += "1";
        }

        public void Btn_2(object sender, RoutedEventArgs e)
        {
            textBox1.Text += "2";
        }

        public void Btn_3(object sender, RoutedEventArgs e)
        {
            textBox1.Text += "3";
        }

        public void Btn_4(object sender, RoutedEventArgs e)
        {
            textBox1.Text += "4";
        }

        public void Btn_5(object sender, RoutedEventArgs e)
        {
            textBox1.Text += "5";
        }

        public void Btn_6(object sender, RoutedEventArgs e)
        {
            textBox1.Text += "6";
        }

        public void Btn_7(object sender, RoutedEventArgs e)
        {
            textBox1.Text += "7";
        }
        
        public void Btn_8(object sender, RoutedEventArgs e)
        {
            textBox1.Text += "8";
        }

        public void Btn_9(object sender, RoutedEventArgs e)
        {
            textBox1.Text += "9";
        }

        public void Btn_0(object sender, RoutedEventArgs e)
        {
            textBox1.Text += "0";
        }

        public void Btn_delit(object sender, RoutedEventArgs e)
        {
            textBox1.Text += " / ";
        }

        public void Btn_umnoz(object sender, RoutedEventArgs e)
        {
            textBox1.Text += " * ";
        }

        public void Btn_minus(object sender, RoutedEventArgs e)
        {
            textBox1.Text += " - ";
        }

        public void Btn_plus(object sender, RoutedEventArgs e)
        {
            textBox1.Text += " + ";
        }

        private void Btn_ravno(object sender, EventArgs e)
        {
        start:
            A.Clear();
            string input = textBox1.Text;
            A.AddRange(input.Split(' '));
            List<int> B = new List<int>();
            int brceil = 0;
            int brtier = 0;
            int brcount = 0;
            int i;

            for (i = 0; i < A.Count; i++)
            {
                if (A[i] == "(" || A[i] == ")")
                {
                    brcount++;
                    if (A[i] == "(")
                    {
                        brtier++;
                    }

                    if (A[i] == ")")
                    {
                        brtier--;
                    }
                    if (brtier > brceil)
                    {
                        brceil = brtier;
                    }
                }
            }
            if (brcount % 2 != 0)
            {
                textBox1.Text = "";
                err.Content = "некорректное количество скобок";
                goto start;
            }
            for (int j = brceil; j >= 0; j--)
            {
                for (i = 0; i < A.Count; i++)
                {
                    if (A[i] == "(" || A[i] == ")")
                    {
                        brcount++;
                        if (A[i] == "(")
                        {
                            brtier++;
                        }

                        if (A[i] == ")")
                        {
                            brtier--;
                        }
                    }
                    if ((A[i] == "*" || A[i] == "/") && brtier == j)
                    {
                        B.Add(i - brcount);
                    }
                }
                brcount = 0;
                for (i = 0; i < A.Count; i++)
                {
                    if (A[i] == "(" || A[i] == ")")
                    {
                        brcount++;
                        if (A[i] == "(")
                        {
                            brtier++;
                        }

                        if (A[i] == ")")
                        {
                            brtier--;
                        }
                    }
                    if ((A[i] == "+" || A[i] == "-") && brtier == j)
                    {
                        B.Add(i - brcount);
                    }
                }
            }
            brcount = 0;
            A.RemoveAll(item => item == "(" || item == ")");
            try
            {
                for (i = 0; i < B.Count; i++)
                {
                    int p = B[i];
                    switch (A[p])
                    {
                        case "*":
                            A[p - 1] = Convert.ToString(double.Parse(A[p - 1]) * double.Parse(A[p + 1]));
                            break;
                        case "/":
                            A[p - 1] = Convert.ToString(double.Parse(A[p - 1]) / double.Parse(A[p + 1]));
                            break;
                        case "+":
                            A[p - 1] = Convert.ToString(double.Parse(A[p - 1]) + double.Parse(A[p + 1]));
                            break;
                        case "-":
                            A[p - 1] = Convert.ToString(double.Parse(A[p - 1]) - double.Parse(A[p + 1]));
                            break;
                    }
                    for (int j = i; j < B.Count; j++)
                        if (B[j] > p) B[j] -= 2;
                    A.RemoveAt(p);
                    if (A.Count < 2)
                        break;
                    if (p < A.Count) A.RemoveAt(p);
                }
                textBox1.Text = A[0];
                err.Content = "";
            }
            catch { textBox1.Text = ""; err.Content = "некорректная формула"; goto start; }

        }

    }
}