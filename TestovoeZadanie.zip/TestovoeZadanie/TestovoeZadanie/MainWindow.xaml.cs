﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using TestovoeZadanie.Models;

namespace TestovoeZadanie
{
    public partial class MainWindow : Window
    {
        // Создаем и добавляем HardSnowfall в Grid
        ClearNight clearNight = new ClearNight { Margin = new Thickness(51, -29, -51, 28)};
        Cloudly cloudly = new Cloudly { Margin = new Thickness(51, -29, -51, 28)};
        Fog fog = new Fog { Margin = new Thickness(51, -29, -51, 28)};
        FreezingDrizzle freezingDrizzle = new FreezingDrizzle { Margin = new Thickness(51, -29, -51, 28)};
        HardSnowfall hardSnowfall = new HardSnowfall { Margin = new Thickness(51, -29, -51, 28)};
        Overcast overcast = new Overcast { Margin = new Thickness(51, -29, -51, 28)};
        PartyCloudlyDay partyCloudlyDay = new PartyCloudlyDay { Margin = new Thickness(51, -29, -51, 28)};
        PartyCloudlyNight partyCloudlyNight = new PartyCloudlyNight { Margin = new Thickness(51, -29, -51, 28)};


        ListBoxItem listBoxItem = new ListBoxItem
        {
            Width = 100,
            Height = 90,
            Background = System.Windows.Media.Brushes.LightGray
        };

        // Создаем Grid
        Grid grid = new Grid();

        //Margin="51,-29,-51,28"
        public MainWindow()
        {
            InitializeComponent();
            AddNewDays(fog);

        }
        private void AddNewDays(UserControl wether)
        {
            
            grid.Children.Add(wether);

            // Добавляем Grid в ListBoxItem
            listBoxItem.Content = grid;

            // Добавляем ListBoxItem в ListBox
            Week.Items.Add(listBoxItem);
        }
    }
}
