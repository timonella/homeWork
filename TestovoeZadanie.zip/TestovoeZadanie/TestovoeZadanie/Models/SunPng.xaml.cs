﻿using System.Windows.Controls;

namespace TestovoeZadanie.Models
{
    public partial class SunPng : UserControl
    {
        public SunPng()
        {
            InitializeComponent();
        }
    }
}
