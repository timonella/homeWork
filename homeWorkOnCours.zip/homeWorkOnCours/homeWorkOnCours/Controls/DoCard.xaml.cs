﻿using System.Windows.Controls;

namespace homeWorkOnCours.Controls
{
    /// <summary>
    /// Логика взаимодействия для DoCard.xaml
    /// </summary>
    public partial class DoCard : UserControl
    {
        public DoCard()
        {
            InitializeComponent();
        }
    }
}
