﻿using System.Windows;
using System.Windows.Controls;

namespace homeWorkOnCours.Controls
{
    /// <summary>
    /// Логика взаимодействия для StatusAlement.xaml
    /// </summary>
    public partial class StatusAlement : UserControl
    {

        public string Text { get; set; }
        public static readonly DependencyProperty TextProperty =
        DependencyProperty.Register(
            "Text",
            typeof(string),
            typeof(StatusAlement),
            new FrameworkPropertyMetadata(string.Empty));


        public StatusAlement()
        {
            InitializeComponent();
            this.DataContext = this;    
        }
    }
}
