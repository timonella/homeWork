﻿using homeWorkOnCours.Controls;
using System.Windows;
using System.Windows.Controls;

namespace homeWorkOnCours
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DogsListBox.ItemsSource = DogsRepositoriy.GetDog();
        }

        private void listChenges(object sender, SelectionChangedEventArgs e)
        {
            /*MainBorder.DataContext = DogsListBox.SelectedItem;
            CountNoteText.DataContext = DogsListBox.SelectedItem;*/
            DoCard curd=new DoCard();
            curd.DataContext=DogsListBox.SelectedItem;
            MainGrid.Children.Add(curd);
        }
    }
}