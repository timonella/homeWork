﻿using System.Windows;

namespace bobriniDvij
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            listBox.ItemsSource = DogsRepos.GetDog();
        }


        private void aboba(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            MainStack.DataContext = listBox.SelectedItem;

        }
    }
}
