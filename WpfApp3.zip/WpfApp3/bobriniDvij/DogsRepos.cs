﻿using System.Collections.Generic;

namespace bobriniDvij
{
    public static class DogsRepos
    {
        private static List<Dog> dogs=new List<Dog>();

        public static List<Dog> GetDog()
        {
            if (dogs.Count == 0) {
                dogs.Add(new Dog("Bob", 4, "Labrodor"));
                dogs.Add(new Dog("Antonio", 2, "Chyizer"));
                dogs.Add(new Dog("Maxim", 3, "Mark2"));
            }
            return dogs;
        }
    }
}
