﻿namespace bobriniDvij
{
    public class Dog
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Tyipe { get; set; }
        public Dog(string name, int age, string tyipe)
        {
            Name = name;
            Age = age;
            Tyipe = tyipe;
        }

    }
}
