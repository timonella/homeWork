﻿using System.Windows;

namespace ne_bobriniy_dvij
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            TaskListBox.ItemsSource = TaskRepositori.GetTask();
        }
    }
}
