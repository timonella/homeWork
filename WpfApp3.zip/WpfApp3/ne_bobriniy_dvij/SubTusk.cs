﻿namespace ne_bobriniy_dvij
{
    public class SubTusk
    {
        public SubTusk()
        {

        }
        public SubTusk(string name, bool isRady)
        {
            Name = name;
            IsRady = isRady;
        }
        public string Name {  get; set; }
        public bool IsRady { get; set; }

    }
}
