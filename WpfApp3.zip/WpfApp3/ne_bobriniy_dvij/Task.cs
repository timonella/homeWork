﻿using System;
using System.Collections.ObjectModel;

namespace ne_bobriniy_dvij
{
    public class Task
    {
        public Task() { }
        public Task(string title, DateTime dateTime, string description, ObservableCollection<SubTusk> subTusks)
        {
            Title = title;
            DateTime = dateTime;
            Description = description;
            SubTusks = subTusks;
        }

        public string Title { get; set; }
        public DateTime DateTime { get; set; }
        public string Description { get; set; }
        public ObservableCollection<SubTusk> SubTusks { get; set; } = new ObservableCollection<SubTusk>();
    }
}
