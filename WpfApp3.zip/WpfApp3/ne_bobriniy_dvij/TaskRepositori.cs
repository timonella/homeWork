﻿using System;
using System.Collections.ObjectModel;

namespace ne_bobriniy_dvij
{
    public static class TaskRepositori
    {
        private static ObservableCollection<Task> tasks =new ObservableCollection<Task> ();

        public static ObservableCollection<Task> GetTask()
        {
            SubTusk subTusk0 = new SubTusk("сходить в кальянку", true);
            SubTusk subTusk1 = new SubTusk("уйти из кальянки", false);
            SubTusk subTusk2 = new SubTusk("Sleep", false);

            ObservableCollection<SubTusk> subTusks = new ObservableCollection<SubTusk> { subTusk0, subTusk1, subTusk2 };

            if (tasks.Count == 0)
            {
                tasks.Add(new Task ("Поспать", DateTime.Now, "незабть про кальянку", subTusks));
            }
            return tasks;
        }
    }
}
