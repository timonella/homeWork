﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Button> bobr=new List<Button>();
        public MainWindow()
        {
            InitializeComponent();

            bobr.Add(BTN1);
            bobr.Add(BTN2);
            bobr.Add(BTN3);
            bobr.Add(BTN4);
            bobr.Add(BTN5);
            bobr.Add(BTN6);
            bobr.Add(BTN7);
            bobr.Add(BTN8);
        }

        private void Btn_Central_Click(object sender, RoutedEventArgs e)
        {
            //BTN1.Background
        }
    }
}
