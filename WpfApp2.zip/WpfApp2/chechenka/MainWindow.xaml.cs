﻿using System.Windows;

namespace chechenka
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }

        private void Btn_Central_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}