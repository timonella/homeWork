﻿using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            byte red1 = (byte)redSlider1.Value;
            byte green1 = (byte)greenSlider1.Value;
            byte blue1 = (byte)blueSlider1.Value;
            Color color1 = Color.FromRgb(red1, green1, blue1);

            // Второй цвет


            // Обновляем GradientStop
            gradientBrush.GradientStops[0].Color = color1;
        }

        private void ArialBtn(object sender, RoutedEventArgs e)
        {
            boxText.FontFamily = new FontFamily("Arial");
        }

        private void GeorgiaBtn(object sender, RoutedEventArgs e)
        {
            boxText.FontFamily = new FontFamily("Georgia");

        }

        private void ComicsBtn(object sender, RoutedEventArgs e)
        {
            boxText.FontFamily = new FontFamily("Comic Sans MS");

        }


        private void HelveticaBtn(object sender, RoutedEventArgs e)
        {
            boxText.FontFamily = new FontFamily("Helvetica");

        }

        private void ConsolasBtn(object sender, RoutedEventArgs e)
        {
            boxText.FontFamily = new FontFamily("Consolas");

        }

        private void GaramondBtn(object sender, RoutedEventArgs e)
        {
            boxText.FontFamily = new FontFamily("Courier New");

        }

        private void BtnItalic(object sender, RoutedEventArgs e)
        {
            boxText.FontStyle =FontStyles.Italic;
        }

        private void BtnNormal(object sender, RoutedEventArgs e)
        {
            boxText.FontStyle =FontStyles.Normal;

        }

        private void BtnObl(object sender, RoutedEventArgs e)
        {
            boxText.FontStyle =FontStyles.Oblique;

        }

        private void BtnBold(object sender, RoutedEventArgs e)
        {
            boxText.FontWeight = FontWeights.Bold;
        }

        private void BtnLight(object sender, RoutedEventArgs e)
        {
            boxText.FontWeight = FontWeights.Light;

        }

        private void BtnExtra(object sender, RoutedEventArgs e)
        {
            boxText.FontWeight = FontWeights.ExtraBold;

        }
    }
}