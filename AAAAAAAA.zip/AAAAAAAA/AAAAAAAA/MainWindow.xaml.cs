﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace AAAAAAAA
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {



        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddNewReceptBtn(object sender, RoutedEventArgs e)
        {
            NewReceptWin Win1 = new NewReceptWin();

            Win1.Show();
            this.Close();
        }

        private void AllSettingsNtn(object sender, RoutedEventArgs e)
        {
            AddNewReceptWindow Win2 = new AddNewReceptWindow();

            Win2.Show();
            this.Close();
        }

        private void ProfileBtn(object sender, RoutedEventArgs e)
        {
            ProfileWindow Win3 = new ProfileWindow();

            Win3.Show();
            this.Close();
        }

        private void bober(object sender, SelectionChangedEventArgs e)
        {
            ListBoxItem selectedItem = BNb.SelectedItem as ListBoxItem;

            if (selectedItem != null)
            {
                Grid grid = selectedItem.Content as Grid;

                TextBlock textBlock = FindVisualChild<TextBlock>(grid);

                if (textBlock != null)
                {
                    MessageBox.Show($"Выбрано: {textBlock.Text}");
                }
            }
        }

        private T FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T result)
                    return result;
                else
                {
                    var descendant = FindVisualChild<T>(child);
                    if (descendant != null)
                        return descendant;
                }
            }
            return null;
        }
    }
}
